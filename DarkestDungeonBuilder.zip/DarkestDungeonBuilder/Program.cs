using System;
using System.Net.Http;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using DarkestDungeonBuilder;
using DarkestDungeonBuilder.Services;
using MudBlazor.Services;
using Blazored.LocalStorage;
using Microsoft.Extensions.DependencyInjection;


var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });

builder.Services.AddMudServices();

builder.Services.AddSingleton<HeroDatabase>();

builder.Services.AddBlazoredLocalStorage();

builder.Services.AddSingleton<DungeonLocationDatabase>();

builder.Services.AddScoped<TrinketDatabase>();

await builder.Build().RunAsync();
