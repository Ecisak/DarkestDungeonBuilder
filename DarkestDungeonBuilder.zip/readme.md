**Darkest Dungeon Team Builder**
webová aplikace v C# Asp.net Core Blazor účelem je poskytnout interaktivní builder více viz. zadaní

**Co je hotovo**
- výběr lokace
- grid všech hrdinů (zatím bez sortingu a filtrování)
- doporučení hrdinů na základě lokace (co se týče bonusového damage vůči různým enemies)
- hluboké kopie hrdinů
- drag and drop hrdiny do rosteru
- drag and drop existujícího hrdiny mezi pozicemi
- lze hrdinu smazat či mu upravit loadout
- omezení na selekci pouze 4 spellů z obou kategorií (jak je ve hře)
- výpočet nejlepší pozice pro hrdinu v týmu na základě vybraných bojových skillů
- výběr trinketu přes TreeView, kde se nejdříve vyfiltrujou trinkety pro daného hrdinu, dále jsou seřazeny dle rarity, implementován  i search kde lze hledat dle parametrů trinketu.
- basic mock pro lokace, hrdiny a trinkety
- každá úprava je uložena do Local Storage

**co je potřeba dodělat**
- grafy
- upozornění když hrdina není na nejlepší pozici a je pro něj dostupná lepší pozice
- zlepšit doporučení hrdinů co se lokace týče
- s pomocí bitfieldů spellů sestavit poradce, který bude checkovat, zda tým disponuje vším (např. upozorní uživatele, když mu chybí healer)
- lepší popis spellů (pravděpodobně nová třída)
- UI a CSS
- UX a QoL
- další různý věcu co mě napadnou

**Spuštění**
vytvářeno na Linuxu v Rideru na .NET 10 SDK.
1. IDE by si mělo samo stáhnout veškeré potřebné balíčky
2. Můžete spouštět